# Love Declaration Website

This project is a fun and interactive web page designed for making a romantic declaration of love. It's perfect for those looking for a creative way to ask someone to be their partner.

## Features

- Diseño responsive con un fondo degradado
- Botones interactivos para respuestas "Sí" y "No"
- Botón de "No" en movimiento que esquiva el cursor
- Poema oculto que aparece al aceptar la propuesta
- Imagen y texto personalizables


## Technologies Used

- HTML5
- CSS3
- JavaScript
- Font Awesome for icons
- Google Fonts for typography

## Setup

1. Clone this repository to your local machine:
   ```
   git clone https://github.com/your-username/love-declaration-website.git
   ```

2. Navigate to the project directory:
   ```
   cd love-declaration-website
   ```

3. Open the `declaracion.html` file in your web browser to view the site locally.

## Customization

To personalize the website for your own use:

1. Replace the image in the `<img>` tag with your own image. Make sure to update the `src` attribute:
   ```html
   <img src="path/to/your/image.jpg" alt="Declaración de amor">
   ```

2. Modify the text in the `<p>` tags to change the main question and poem.

3. Adjust the colors in the CSS to match your preferences. Look for the `background-image` property in the `body` selector and the color properties throughout the CSS.

4. If desired, update the alert messages in the JavaScript section at the bottom of the file.

## Deployment

You can deploy this website using GitHub Pages:

1. Push your changes to your GitHub repository.
2. Go to your repository settings on GitHub.
3. Navigate to the "Pages" section.
4. Select the branch you want to deploy (usually `main` or `master`).
5. Click "Save" and GitHub will provide you with a URL for your live site.


## License

This project is open source and available under the [MIT License](LICENSE).

## Credits

Created with ❤️ by [Darkiel]

Inspired by creative web developers and romantics everywhere.